int StrokeFontExt (Tcl_Interp *interp, int argc, char* argv []);


